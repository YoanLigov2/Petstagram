from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

from petstagram_pj.photos.models import Photo
from .forms import PhotoForm, PhotoEditForm
from ..common.forms import CommentForm


# Create your views here.
@login_required
def photo_add(request):
    form = PhotoForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        photo = form.save(commit=False)
        photo.user = request.user
        photo.save()
        form.save_m2m()
        return redirect('home-page')
    return render(request, 'photos/photo-add-page.html', {'form': form})


@login_required
def photo_details(request, pk):
    photo = Photo.objects.get(pk=pk)
    likes = photo.like_set.all()
    comments = photo.comment_set.all()
    comment_form = CommentForm()
    owner = photo.user
    context = {
        'likes': likes,
        'photo': photo,
        'comments': comments,
        'comment_form': comment_form,
        'owner': owner
    }
    return render(request, 'photos/photo-details-page.html', context)


@login_required
def photo_edit(request, pk):
    photo = Photo.objects.get(pk=pk)
    form = PhotoEditForm(request.POST or None, instance=photo)
    if form.is_valid():
        form.save()
        return redirect('photo-details', pk=pk)
    return render(request, 'photos/photo-edit-page.html', {'form': form})


@login_required
def photo_delete(request, pk):
    photo = Photo.objects.get(pk=pk)
    photo.delete()
    return redirect('home-page')