from django.urls import path, include
from .views import index, like_func, copy_link_to_clipboard, add_comment

urlpatterns = [
    path('', index, name='home-page'),
    path('like/<int:photo_id>/', like_func, name='like'),
    path('share/<int:photo_id>/', copy_link_to_clipboard, name='share'),
    path('comment/<int:pk>/', add_comment, name='add-comment')
]
