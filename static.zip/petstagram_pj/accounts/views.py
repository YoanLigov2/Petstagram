from django.shortcuts import render
from django.urls import reverse_lazy

from .forms import PetstagramUserCreationForm, LoginForm, PetstagramUserEditForm
from .models import PetstagramUser
from django.views.generic import CreateView, UpdateView, DetailView, DeleteView
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin


# Create your views here.
# def register(request):
#     return render(request, 'accounts/register-page.html')
class UserRegistrationView(CreateView):
    model = PetstagramUser
    form_class = PetstagramUserCreationForm
    template_name = 'accounts/register-page.html'
    success_url = reverse_lazy('login')


# def login(request):
#     return render(request, 'accounts/login-page.html')
class UserLoginView(LoginView):
    form_class = LoginForm
    template_name = 'accounts/login-page.html'
    next_page = reverse_lazy('home-page')


class UserLogoutView(LoginRequiredMixin, LogoutView):
    next_page = reverse_lazy('login')


# def profile_details(request, pk):
#     return render(request, 'accounts/profile-details-page.html')
class UserDetailView(LoginRequiredMixin, DetailView):
    model = PetstagramUser
    template_name = 'accounts/profile-details-page.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        total_likes_count = sum(p.like_set.count() for p in self.object.photo_set.all())

        context.update({
            'total_likes_count': total_likes_count,
        })
        print(context)
        return context


# def profile_edit(request, pk):
#     return render(request, 'accounts/profile-edit-page.html')
class UserEditView(LoginRequiredMixin, UpdateView):
    model = PetstagramUser
    form_class = PetstagramUserEditForm
    template_name = 'accounts/profile-edit-page.html'

    def get_success_url(self):
        return reverse_lazy('profile-details', kwargs={'pk': self.object.pk})


# def profile_delete(request, pk):
#     return render(request, 'accounts/profile-delete-page.html')
class UserDeleteView(LoginRequiredMixin, DeleteView):
    model = PetstagramUser
    template_name = 'accounts/profile-delete-page.html'
    success_url = reverse_lazy('home-page')



