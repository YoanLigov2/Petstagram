from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

from petstagram_pj.pets.models import Pet
from .forms import PetForm, PetDeleteForm
from ..accounts.models import PetstagramUser
from ..common.forms import CommentForm


# Create your views here.
@login_required
def add_pet(request):
    form = PetForm(request.POST or None)
    if form.is_valid():
        pet = form.save(commit=False)
        pet.user = request.user
        pet.save()
        return redirect('profile-details', pk=1)
    return render(request, 'pets/pet-add-page.html', {'form': form})


@login_required
def pet_details(request, username, pet_slug):
    pet = Pet.objects.get(slug=pet_slug)
    owner = PetstagramUser.objects.get(username=username)
    all_photos = pet.photo_set.all()
    comment_form = CommentForm()
    context = {
        'pet': pet,
        'all_photos': all_photos,
        'comment_form': comment_form,
        'owner': owner
    }
    return render(request, 'pets/pet-details-page.html', context)


@login_required
def pet_edit(request, username, pet_slug):
    pet = Pet.objects.get(slug=pet_slug)
    form = PetForm(request.POST or None, instance=pet)
    if form.is_valid():
        form.save()
        return redirect('pet-details', username, pet_slug)
    return render(request, 'pets/pet-edit-page.html', {'form': form})


@login_required
def pet_delete(request, username, pet_slug):
    pet = Pet.objects.get(slug=pet_slug)
    if request.method == "POST":
        pet.delete()
        return redirect('profile-details', pk=1)
    form = PetDeleteForm(initial=pet.__dict__)
    return render(request, 'pets/pet-delete-page.html', {'form': form})
